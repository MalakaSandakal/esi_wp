<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Energy_Security
 */

?>
<div class="single-blog">
        <div class="container">
            <?php
                the_content();
            ?>     
        </div>
    </div>